package com.labirent.core;
import com.labirent.model.Cell;

public interface IMazeGenerator {
    Cell[][] generate(int width, int height);
}
    

