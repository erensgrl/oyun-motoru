package com.labirent.model;

public enum CellType {
    EMPTY,
    WALL,
    START,
    END,
    PATH
}
